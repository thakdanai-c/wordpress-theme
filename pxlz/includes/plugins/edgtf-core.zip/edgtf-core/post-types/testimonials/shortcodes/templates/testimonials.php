<div class="edgtf-testimonial-content" id="edgtf-testimonials-<?php echo esc_attr($current_id) ?>">
    <div class="edgtf-testimonial-text-holder">
        <?php if (!empty($text)) { ?>
            <p class="edgtf-testimonial-text" <?php echo pxlz_edgtf_inline_style($content_styles); ?>><?php echo esc_html($text); ?></p>
        <?php } ?>
        <?php if (!empty($author)) { ?>
            <div class="edgtf-testimonials-author-holder clearfix">
                <div class="edgtf-testimonial-author" <?php echo pxlz_edgtf_inline_style($author_styles); ?>>
                    <span class="edgtf-testimonials-author-name"><?php echo esc_html($author); ?></span>
                    <?php if (!empty($position)) { ?>
                        <span class="edgtf-testimonials-author-job"><?php echo esc_html($position); ?></span>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    </div>
</div>