<?php if (pxlz_edgtf_options()->getOptionValue('portfolio_single_hide_pagination') !== 'yes') : ?>
    <?php
    $back_to_link = get_post_meta(get_the_ID(), 'portfolio_single_back_to_link', true);
    $nav_same_category = pxlz_edgtf_options()->getOptionValue('portfolio_single_nav_same_category') == 'yes';

    $prev_link = '<span class="edgtf-portfolio-single-nav-background-label">' . esc_html__('Prev', 'edgtf-core') . '</span><span class="edgtf-portfolio-single-nav-label">' . esc_html__('Previous project', 'edgtf-core') . '</span>';
    $next_link = '<span class="edgtf-portfolio-single-nav-background-label">' . esc_html__('Next', 'edgtf-core') . '</span><span class="edgtf-portfolio-single-nav-label">' . esc_html__('Next project', 'edgtf-core') . '</span>';

    ?>
    <div class="edgtf-ps-navigation">
        <div class="edgtf-ps-prev">
            <?php if (get_previous_post() !== '') : ?>
                <?php if ($nav_same_category) {
                    previous_post_link('%link', $prev_link, true, '', 'portfolio-category');
                } else {
                    previous_post_link('%link', $prev_link);
                } ?>
            <?php endif; ?>
        </div>


        <?php if ($back_to_link !== '') : ?>
            <div class="edgtf-ps-back-btn">
                <a itemprop="url" href="<?php echo esc_url(get_permalink($back_to_link)); ?>">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </a>
            </div>
        <?php endif; ?>

        <div class="edgtf-ps-next">
            <?php if (get_next_post() !== '') : ?>
                <?php if ($nav_same_category) {
                    next_post_link('%link', $next_link, true, '', 'portfolio-category');
                } else {
                    next_post_link('%link', $next_link);
                } ?>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>