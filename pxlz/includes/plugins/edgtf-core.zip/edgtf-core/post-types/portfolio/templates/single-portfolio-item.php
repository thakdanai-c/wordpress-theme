<?php

get_header();

pxlz_edgtf_get_title();

do_action('pxlz_edgtf_before_main_content');

edgtf_core_get_single_portfolio();

get_footer();