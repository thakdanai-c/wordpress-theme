<?php

if (!function_exists('edgtf_core_map_portfolio_meta')) {
    function edgtf_core_map_portfolio_meta() {
        global $pxlz_edgtf_Framework;

        $edgtf_pages = array();
        $pages = get_pages();
        foreach ($pages as $page) {
            $edgtf_pages[$page->ID] = $page->post_title;
        }

        //Portfolio Images

        $edgtPortfolioImages = new PxlzEdgefMetaBox('portfolio-item', esc_html__('Portfolio Images (multiple upload)', 'edgtf-core'), '', '', 'portfolio_images');
        $pxlz_edgtf_Framework->edgtMetaBoxes->addMetaBox('portfolio_images', $edgtPortfolioImages);

        $edgtf_portfolio_image_gallery = new PxlzEdgefMultipleImages('edgtf-portfolio-image-gallery', esc_html__('Portfolio Images', 'edgtf-core'), esc_html__('Choose your portfolio images', 'edgtf-core'));
        $edgtPortfolioImages->addChild('edgtf-portfolio-image-gallery', $edgtf_portfolio_image_gallery);

        //Portfolio Images/Videos 2

        $edgtPortfolioImagesVideos2 = new PxlzEdgefMetaBox('portfolio-item', esc_html__('Portfolio Images/Videos (single upload)', 'edgtf-core'));
        $pxlz_edgtf_Framework->edgtMetaBoxes->addMetaBox('portfolio_images_videos2', $edgtPortfolioImagesVideos2);

        $edgtf_portfolio_images_videos2 = new PxlzEdgefImagesVideosFramework('', '');
        $edgtPortfolioImagesVideos2->addChild('edgtf_portfolio_images_videos2', $edgtf_portfolio_images_videos2);

        //Portfolio Additional Sidebar Items

        $edgtAdditionalSidebarItems = pxlz_edgtf_create_meta_box(
            array(
                'scope' => array('portfolio-item'),
                'title' => esc_html__('Additional Portfolio Sidebar Items', 'edgtf-core'),
                'name' => 'portfolio_properties'
            )
        );

        $edgtf_portfolio_properties = pxlz_edgtf_add_options_framework(
            array(
                'label' => esc_html__('Portfolio Properties', 'edgtf-core'),
                'name' => 'edgtf_portfolio_properties',
                'parent' => $edgtAdditionalSidebarItems
            )
        );
    }

    add_action('pxlz_edgtf_meta_boxes_map', 'edgtf_core_map_portfolio_meta', 40);
}