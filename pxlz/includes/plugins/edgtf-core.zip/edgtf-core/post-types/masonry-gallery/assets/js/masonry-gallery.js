(function ($) {
    'use strict';

    var masonryGallery = {};
    edgtf.modules.masonryGallery = masonryGallery;

    masonryGallery.edgtfInitMasonryGallery = edgtfInitMasonryGallery;
    masonryGallery.edgtfMasonryGalleryTextAnimation = edgtfMasonryGalleryTextAnimation;


    masonryGallery.edgtfOnDocumentReady = edgtfOnDocumentReady;

    $(document).ready(edgtfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function edgtfOnDocumentReady() {
        edgtfInitMasonryGallery();
        edgtfMasonryGalleryTextAnimation();
    }

    /**
     * Masonry gallery, init masonry and resize pictures in grid
     */
    function edgtfInitMasonryGallery() {
        var galleryHolder = $('.edgtf-masonry-gallery-holder'),
            gallery = galleryHolder.children('.edgtf-mg-inner'),
            gallerySizer = gallery.children('.edgtf-mg-grid-sizer');

        resizeMasonryGallery(gallerySizer.outerWidth(), gallery);

        if (galleryHolder.length) {
            galleryHolder.each(function () {
                var holder = $(this),
                    holderGallery = holder.children('.edgtf-mg-inner');

                holderGallery.waitForImages(function () {
                    holderGallery.animate({opacity: 1});

                    holderGallery.isotope({
                        layoutMode: 'packery',
                        itemSelector: '.edgtf-mg-item',
                        percentPosition: true,
                        packery: {
                            gutter: '.edgtf-mg-grid-gutter',
                            columnWidth: '.edgtf-mg-grid-sizer'
                        }
                    });
                });
            });

            $(window).resize(function () {
                resizeMasonryGallery(gallerySizer.outerWidth(), gallery);

                gallery.isotope('reloadItems');
            });
        }
    }

    function resizeMasonryGallery(size, holder) {
        var rectangle_portrait = holder.find('.edgtf-mg-rectangle-portrait'),
            rectangle_landscape = holder.find('.edgtf-mg-rectangle-landscape'),
            square_big = holder.find('.edgtf-mg-square-big'),
            square_small = holder.find('.edgtf-mg-square-small'),
            margin = 0;

        if (holder.parent().hasClass('edgtf-huge-space')) {
            margin = 80;
        } else if (holder.parent().hasClass('edgtf-large-space')) {
            margin = 50;
        } else if (holder.parent().hasClass('edgtf-medium-space')) {
            margin = 40;
        } else if (holder.parent().hasClass('edgtf-normal-space')) {
            margin = 30;
        } else if (holder.parent().hasClass('edgtf-small-space')) {
            margin = 20;
        } else if (holder.parent().hasClass('edgtf-tiny-space')) {
            margin = 10;
        }

        size = size * 0.69;

        // portrait
        rectangle_portrait.css('height', (2 * size) + margin);

        // landscape
        if (window.innerWidth <= 680) {
            rectangle_landscape.css('height', size / 2);
        } else {
            rectangle_landscape.css('height', size);
        }

        // large square
        square_big.css('height', (2 * size) + margin);
        if (window.innerWidth <= 680) {
            square_big.css('height', square_big.width());
        }

        // small square
        square_small.css('height', size);
    }

    function edgtfMasonryGalleryTextAnimation() {
        var masonryArticles = $('.edgtf-mg-simple .edgtf-mg-item-title > span').closest('article');

        if (masonryArticles.length && !edgtf.htmlEl.hasClass('touch')) {
            var delay = 250;
            
            masonryArticles.each(function(){
                var masonryArticle = $(this),
                    txtElements = masonryArticles.find('span').addClass('edgtf-animate-text');

                txtElements.each(function(i){
                    var txtElement = $(this);

                    txtElement.wrap( "<span class='edgtf-animate-text-holder'></span>" );

                    txtElement.appear(function(){
                        setTimeout(function(){
                            txtElement.addClass('edgtf-appeared');
                        }, i*delay);
                    });
                });
            });
        }
    }

})(jQuery);