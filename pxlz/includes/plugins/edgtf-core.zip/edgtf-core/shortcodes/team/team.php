<?php
namespace EdgeCore\CPT\Shortcodes\Team;

use EdgeCore\Lib;

class Team implements Lib\ShortcodeInterface
{
    private $base;

    public function __construct() {
        $this->base = 'edgtf_team';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name' => esc_html__('Edge Team', 'edgtf-core'),
                    'base' => $this->getBase(),
                    'category' => esc_html__('by EDGE', 'edgtf-core'),
                    'icon' => 'icon-wpb-team extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
                    'params' => array(
                        array(
                            'type' => 'attach_image',
                            'heading' => esc_html__('Image', 'edgtf-core'),
                            'param_name' => 'image',
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__('Name', 'edgtf-core'),
                            'admin_label' => true,
                            'param_name' => 'name',
                        ),
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'team_name_tag',
                            'heading' => esc_html__('Name Tag', 'edgtf-core'),
                            'value' => array_flip(pxlz_edgtf_get_title_tag(true)),
                            'dependency' => array(
                                'element' => 'name',
                                'not_empty' => true,
                            )
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'position',
                            'heading' => esc_html__('Position', 'edgtf-core'),
                            'admin_label' => true,
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'position_color',
                            'heading' => esc_html__('Position Text Color', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'position',
                                'not_empty' => true,
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'position_font_size',
                            'heading' => esc_html__('Position Font Size (px)', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'position',
                                'not_empty' => true,
                            ),
                        ),
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'image' => '',
            'name' => '',
            'name_tag' => 'h3',
            'position' => '',
            'position_color' => '',
            'position_font_size' => '',
        );
        $params = shortcode_atts($args, $atts);

        $params['name_tag'] = $this->getTeamNameTag($params, $args);
        $params['position_styles'] = $this->getPositionStyles($params);

        $html = edgtf_core_get_shortcode_module_template_part('templates/team', 'team', '', $params);

        return $html;
    }

    private function getTeamNameTag($params, $args) {
        $headings_array = array('h2', 'h3', 'h4', 'h5', 'h6');
        return (in_array($params['name_tag'], $headings_array)) ? $params['name_tag'] : $args['name_tag'];
    }

    private function getPositionStyles($params) {
        $styles = array();

        $styles[] = !empty($params['position_color']) ? 'color:' . $params['position_color'] : '';
        $styles[] = !empty($params['position_font_size']) ? 'font-size:' . pxlz_edgtf_filter_px($params['position_font_size']) . 'px' : '';

        return implode(';', $styles);
    }
}