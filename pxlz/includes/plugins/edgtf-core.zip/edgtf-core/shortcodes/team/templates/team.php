<?php
/**
 * Team info on hover shortcode template
 */
?>
<div class="edgtf-team">
    <?php if ($image !== '') { ?>
        <div class="edgtf-team-image">
            <?php echo wp_get_attachment_image($image, 'full'); ?>
        </div>
    <?php } ?>
    <div class="edgtf-team-content-outer">
        <?php if ($name !== '' || $position !== '') { ?>
        <div class="edgtf-team-content">
            <div class="edgtf-team-content-inner">
                <?php if ($name !== '' || $position !== '') { ?>
                    <div class="edgtf-team-title-holder">
                        <?php if ($name !== '') { ?>
                            <?php echo '<' . esc_attr($name_tag); ?> class="edgtf-team-name">
                            <?php echo esc_attr($name); ?>
                            <?php echo '</' . esc_attr($name_tag); ?>>
                        <?php } ?>
                    </div>
                    <?php if ($position !== "") { ?>
                        <div class="edgtf-team-position-holder">
                            <span class="edgtf-team-position" <?php echo pxlz_edgtf_get_inline_style($position_styles); ?>><?php echo esc_attr($position) ?></span>
                        </div>
                    <?php } ?>
                <?php } ?>
            </div>
            <?php } ?>
        </div>
    </div>
</div>