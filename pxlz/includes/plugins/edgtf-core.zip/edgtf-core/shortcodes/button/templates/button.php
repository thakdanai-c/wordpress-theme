<button type="submit" <?php pxlz_edgtf_inline_style($button_styles); ?> <?php pxlz_edgtf_class_attribute($button_classes); ?> <?php echo pxlz_edgtf_get_inline_attrs($button_data); ?> <?php echo pxlz_edgtf_get_inline_attrs($button_custom_attrs); ?>>
    <span class="edgtf-btn-text"><?php echo esc_html($text); ?></span>
    <?php echo pxlz_edgtf_icon_collections()->renderIcon($icon, $icon_pack); ?>
    <?php if (($enable_cover_effect == 'yes') && (($type == 'solid') || ($type == 'outline'))) : ?>
	    <div class="edgtf-btn-cover">
	    	<span class="edgtf-btn-text edgtf-btn-cover-text" <?php pxlz_edgtf_inline_style($button_hover_color_styles); ?>>
	    		<span>
	    			<?php echo esc_html($text); ?>
				</span>	
	    	</span>
	    	<?php echo pxlz_edgtf_icon_collections()->renderIcon($icon, $icon_pack); ?>
	    	<div class="edgtf-btn-cover-bgrnd" <?php pxlz_edgtf_inline_style($button_hover_background_styles); ?>></div>
	    </div>
	<?php endif; ?>
</button>