<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/google-map/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/google-map/google-map.php';