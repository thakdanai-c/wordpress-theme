<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/pricing-table/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/pricing-table/pricing-table.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/pricing-table/pricing-table-item.php';