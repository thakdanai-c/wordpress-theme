<?php
namespace EdgeCore\CPT\Shortcodes\PricingTable;

use EdgeCore\Lib;

class PricingTableItem implements Lib\ShortcodeInterface
{
    private $base;

    function __construct() {
        $this->base = 'edgtf_pricing_table_item';
        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name' => esc_html__('Edge Pricing Table Item', 'edgtf-core'),
                    'base' => $this->base,
                    'icon' => 'icon-wpb-pricing-table-item extended-custom-icon',
                    'category' => esc_html__('by EDGE', 'edgtf-core'),
                    'allowed_container_element' => 'vc_row',
                    'as_child' => array('only' => 'edgtf_pricing_table'),
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'param_name' => 'custom_class',
                            'heading' => esc_html__('Custom CSS Class', 'edgtf-core'),
                            'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS', 'edgtf-core')
                        ),
                        array(
                            'type' => 'checkbox',
                            'param_name' => 'featured',
                            'heading' => esc_html__('Featured', 'edgtf-core'),
                            'description' => esc_html__('Set this table to be featured table', 'edgtf-core'),
                            'value' => true,
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'title',
                            'heading' => esc_html__('Title', 'edgtf-core'),
                            'value' => esc_html__('Basic', 'edgtf-core'),
                            'save_always' => true
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'price',
                            'heading' => esc_html__('Price', 'edgtf-core')
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'currency',
                            'heading' => esc_html__('Currency', 'edgtf-core'),
                            'description' => esc_html__('Default mark is $', 'edgtf-core')
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'price_period',
                            'heading' => esc_html__('Price Period', 'edgtf-core'),
                            'description' => esc_html__('Default label is monthly', 'edgtf-core')
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'button_text',
                            'heading' => esc_html__('Button Text', 'edgtf-core'),
                            'value' => esc_html__('Purchase', 'edgtf-core'),
                            'save_always' => true
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'button_link',
                            'heading' => esc_html__('Button Link', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'button_text',
                                'not_empty' => true
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'button_color',
                            'heading' => esc_html__('Button Color', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'button_text',
                                'not_empty' => true
                            )
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'button_background_color',
                            'heading' => esc_html__('Button Background Color', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'button_text',
                                'not_empty' => true
                            )
                        ),
                        array(
                            'type' => 'textarea_html',
                            'param_name' => 'content',
                            'heading' => esc_html__('Content', 'edgtf-core'),
                        )
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'custom_class' => '',
            'featured' => '',
            'title' => '',
            'price' => '100',
            'currency' => '$',
            'price_period' => 'monthly',
            'button_text' => '',
            'button_link' => '',
            'button_color' => '',
            'button_background_color' => '',
        );
        $params = shortcode_atts($args, $atts);

        $params['content'] = preg_replace('#^<\/p>|<p>$#', '', $content); // delete p tag before and after content
        $params['holder_classes'] = $this->getHolderClasses($params);

        $html = edgtf_core_get_shortcode_module_template_part('templates/pricing-table-template', 'pricing-table', '', $params);

        return $html;
    }

    private function getHolderClasses($params) {
        $holderClasses = array();

        $holderClasses[] = (!empty($params['custom_class'])) ? esc_attr($params['custom_class']) : '';
        $holderClasses[] = (!empty($params['featured'])) ? 'edgtf-featured' : '';

        return implode(' ', $holderClasses);
    }
}