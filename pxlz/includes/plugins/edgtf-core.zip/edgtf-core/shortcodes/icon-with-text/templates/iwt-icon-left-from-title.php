<div <?php pxlz_edgtf_class_attribute($holder_classes); ?>>
    <div class="edgtf-iwt-content" <?php pxlz_edgtf_inline_style($content_styles); ?>>
        <?php if (!empty($title)) : ?>
            <?php echo '<' . esc_attr($title_tag); ?> class="edgtf-iwt-title" <?php pxlz_edgtf_inline_style($title_styles); ?>>
            <?php if (!empty($link)) : ?>
                <a itemprop="url" href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>">
            <?php endif; ?>
            <span class="edgtf-iwt-icon">
                <?php
                if ($icon_source == 'icon-pack') {
                    $params = $icon_parameters;
                } elseif ($icon_source == 'image') {
                    $params = $image;
                } elseif ($icon_source == 'svg-path') {
                    $params = $svg_parameters;
                }

                echo edgtf_core_get_shortcode_module_template_part('templates/' . $icon_source, 'icon-with-text', '', array('params' => $params));
                ?>
            </span>
            <span class="edgtf-iwt-title-text"><?php echo esc_html($title); ?></span>
            <?php if (!empty($link)) : ?>
                </a>
            <?php endif; ?>
            <?php echo '</' . esc_attr($title_tag); ?>>
        <?php endif; ?>
        <?php if (!empty($text)) : ?>
            <p class="edgtf-iwt-text" <?php pxlz_edgtf_inline_style($text_styles); ?>><?php echo esc_html($text); ?></p>
        <?php endif; ?>
    </div>
</div>