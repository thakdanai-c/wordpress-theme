<div <?php echo pxlz_edgtf_get_inline_style($title_styles); ?>>
    <?php echo '<' . esc_attr($title_tag); ?> class="edgtf-accordion-title <?php echo esc_attr($title_classes); ?>" <?php echo pxlz_edgtf_get_inline_style($title_styles); ?>>
        <span class="edgtf-accordion-mark">
            <span class="edgtf_icon_plus fa fa-plus"></span>
            <span class="edgtf_icon_minus fa fa-minus"></span>
        </span>
    <span class="edgtf-tab-title"><?php echo esc_html($title); ?></span>
    <?php echo '</' . esc_attr($title_tag); ?>>
</div>
<div class="edgtf-accordion-content">
    <div class="edgtf-accordion-content-inner">
        <?php echo do_shortcode($content); ?>
    </div>
</div>