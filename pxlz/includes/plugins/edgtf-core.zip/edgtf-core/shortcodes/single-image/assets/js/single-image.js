(function ($) {
    'use strict';

    var singleImage = {};
    edgtf.modules.singleImage = singleImage;

    singleImage.edgtfInitSingleImage = edgtfInitSingleImage;


    singleImage.edgtfOnDocumentReady = edgtfOnDocumentReady;

    $(document).ready(edgtfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function edgtfOnDocumentReady() {
        edgtfInitSingleImage();
    }

    /*
     *	Init animation holder shortcode
     */
    function edgtfInitSingleImage() {
        var elements = $('.edgtf-single-image-holder.edgtf-appear-animation');

        if (elements.length) {
            elements.each(function () {
                var thisElement = $(this);

                thisElement.appear(function () {

                    thisElement.addClass('edgtf-appeared');

                }, {accX: 0, accY: edgtfGlobalVars.vars.edgtfElementAppearAmount});
            });
        }
    }

})(jQuery);