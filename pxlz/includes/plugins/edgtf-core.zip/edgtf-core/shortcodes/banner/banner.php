<?php
namespace EdgeCore\CPT\Shortcodes\Banner;

use EdgeCore\Lib;

class Banner implements Lib\ShortcodeInterface
{
    private $base;

    public function __construct() {
        $this->base = 'edgtf_banner';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name' => esc_html__('Edge Banner', 'edgtf-core'),
                    'base' => $this->getBase(),
                    'category' => esc_html__('by EDGE', 'edgtf-core'),
                    'icon' => 'icon-wpb-banner extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'param_name' => 'custom_class',
                            'heading' => esc_html__('Custom CSS Class', 'edgtf-core'),
                            'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS', 'edgtf-core')
                        ),
                        array(
                            'type' => 'attach_image',
                            'param_name' => 'image',
                            'heading' => esc_html__('Image', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'title',
                            'heading' => esc_html__('Title', 'edgtf-core'),
                            'save_always' => true,
                        ),
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'title_tag',
                            'heading' => esc_html__('Title Tag', 'edgtf-core'),
                            'value' => array_flip(pxlz_edgtf_get_title_tag(true)),
                            'save_always' => true,
                            'dependency' => array('element' => 'title', 'not_empty' => true),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'title_color',
                            'heading' => esc_html__('Title Color', 'edgtf-core'),
                            'dependency' => array('element' => 'title', 'not_empty' => true),
                        ),
                        array(
                            'type' => 'textarea',
                            'param_name' => 'text',
                            'heading' => esc_html__('Text', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'text_color',
                            'heading' => esc_html__('Text Color', 'edgtf-core'),
                            'dependency' => array('element' => 'text', 'not_empty' => true),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'content_background_color',
                            'heading' => esc_html__('Content Background Color', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'button_link',
                            'heading' => esc_html__('Button Link', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'button_target',
                            'heading' => esc_html__('Button Target', 'edgtf-core'),
                            'value' => array_flip(pxlz_edgtf_get_link_target_array()),
                            'save_always' => true,
                            'dependency' => array(
                                'element' => 'button_link',
                                'not_empty' => true,
                            ),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'button_label',
                            'heading' => esc_html__('Button Label', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'button_link',
                                'not_empty' => true,
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'button_color',
                            'heading' => esc_html__('Button Color', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'button_link',
                                'not_empty' => true,
                            ),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'button_background_color',
                            'heading' => esc_html__('Button Background Color', 'edgtf-core'),
                            'dependency' => array(
                                'element' => 'button_link',
                                'not_empty' => true,
                            ),
                        ),
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'enable_appear_animation',
                            'heading' => esc_html__('Enable Appear Animation', 'edgtf-core'),
                            'value' => array_flip( pxlz_edgtf_get_yes_no_select_array( false, false ) ),
                        ),
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'custom_class' => '',
            'image' => '',
            'title' => '',
            'title_tag' => 'h3',
            'title_color' => '',
            'text' => '',
            'text_color' => '',
            'content_background_color' => '',
            'button_link' => '',
            'button_target' => '',
            'button_label' => '',
            'button_color' => '',
            'button_background_color' => '',
            'enable_appear_animation' => ''
        );
        $params = shortcode_atts($args, $atts);

        $params['holder_classes'] = $this->getHolderClasses($params);
        $params['title_styles'] = $this->getTitleStyles($params);
        $params['text_styles'] = $this->getTextStyles($params);
        $params['content_styles'] = $this->getContentStyles($params);

        $params['title_tag'] = !empty($params['title_tag']) ? $params['title_tag'] : $args['title_tag'];

        $html = edgtf_core_get_shortcode_module_template_part('templates/banner', 'banner', '', $params);

        return $html;
    }

    private function getHolderClasses($params) {
        $holderClasses = array();

        $holderClasses[] = !empty($params['custom_class']) ? esc_attr($params['custom_class']) : '';
        $holderClasses[] = !empty($params['image']) ? 'edgtf-with-image' : '';
        $holderClasses[] = !empty($params['button_label']) ? 'edgtf-with-button' : '';
        $holderClasses[] = !empty($params['enable_appear_animation']) ? 'edgtf-enable-appear-animation' : '';

        return implode(' ', $holderClasses);
    }

    private function getTitleStyles($params) {
        $styles = array();

        $styles[] = !empty($params['title_color']) ? 'color: ' . $params['title_color'] : '';

        return implode(';', $styles);
    }

    private function getTextStyles($params) {
        $styles = array();

        $styles[] = !empty($params['text_color']) ? 'color: ' . $params['text_color'] : '';

        return implode(';', $styles);
    }

    private function getContentStyles($params) {
        $styles = array();

        $styles[] = !empty($params['content_background_color']) ? 'background-color: ' . $params['content_background_color'] : '';

        return implode(';', $styles);
    }
}