(function ($) {
    'use strict';

    var banner = {};
    edgtf.modules.banner = banner;

    banner.edgtfInitBanner = edgtfInitBanner;


    banner.edgtfOnDocumentReady = edgtfOnDocumentReady;

    $(document).ready(edgtfOnDocumentReady);
    $(window).resize(edgtfOnWindowResize);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function edgtfOnDocumentReady() {
        edgtfInitBanner();
        edgtfInitBannerTextAnimation();
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function edgtfOnWindowResize() {
        edgtfInitBanner();
    }

    /*
     **	Init Banner Shortcode
     */
    function edgtfInitBanner() {
        var banners = $('.edgtf-banner-holder');

        if (banners.length) {
            banners.each(function () {
                var bannerHolder = $(this),
                    banner = $(this).find('.edgtf-banner'),
                    content = $(this).find('.edgtf-banner-content'),
                    button = $(this).find('.edgtf-banner-button'),
                    margin = 0;

                // fetch height if banner content exists
                if (content.length) {
                    // if banner has class 'with image', use content and button for calculation
                    if (bannerHolder.hasClass('edgtf-with-image')) {
                        // fetch content height
                        margin += parseInt(content.innerHeight());

                        // if button exist, fetch its height as well
                        if (button.length) {
                            margin += parseInt(button.innerHeight());
                        }
                    }
                    // else use only button for calculation
                    else {
                        // fetch button height
                        if (button.length) {
                            margin += parseInt(button.innerHeight());
                        }
                    }

                    // set half of calculated height as banner bottom margin
                    banner.css('margin-bottom', margin / 2);

                    if(bannerHolder.hasClass("edgtf-enable-appear-animation")){
                        bannerHolder.addClass('edgtf-banner-appear');

                        bannerHolder.appear(function(){
                            bannerHolder.addClass('edgtf-banner-appeared');
                        });
                    }
                }
            });
        }
    }

    /*
    ** Appear animation
    */
    function edgtfInitBannerTextAnimation() {
        var banners = $('.edgtf-banner-title > em').closest('.edgtf-banner');

        if (banners.length && !edgtf.htmlEl.hasClass('touch')) {
            var delay = 250;

            banners.each(function() {
                var banner = $(this),
                    animatedTxtElements = banner.find('.edgtf-banner-title > em').addClass('edgtf-animate-text');

                animatedTxtElements.each(function(i){
                    var txtElement = $(this);

                    txtElement.wrap( "<span class='edgtf-animate-text-holder'></span>" );

                    banner.appear(function(){
                        setTimeout(function(){
                            txtElement.addClass('edgtf-appeared');
                        }, i*delay);
                    });
                });
            });
        }
    }

})(jQuery);