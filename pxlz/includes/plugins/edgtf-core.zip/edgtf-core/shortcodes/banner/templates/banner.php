<div class="edgtf-banner-holder clearfix <?php echo esc_attr($holder_classes); ?>">
    <div class="edgtf-banner">

        <?php if (!empty($image)): ?>
            <div class="edgtf-banner-image">
                <?php echo wp_get_attachment_image($image, 'full'); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($title) || !empty($text)): ?>

            <div class="edgtf-banner-content" <?php echo pxlz_edgtf_inline_style($content_styles); ?>>

                <?php if (!empty($title)): ?>
                    <?php echo '<' . esc_attr($title_tag); ?> class="edgtf-banner-title" <?php echo pxlz_edgtf_inline_style($title_styles); ?>>
                    <?php echo wp_kses($title, array('em' => array(), 'br' => array())); ?>
                    <?php echo '</' . esc_attr($title_tag); ?>>
                <?php endif; ?>

                <?php if (!empty($text)): ?>
                    <span class="edgtf-banner-text" <?php echo pxlz_edgtf_inline_style($text_styles); ?>><?php echo esc_attr($text); ?></span>
                <?php endif; ?>

                <?php if (!empty($button_label)): ?>
                    <div class="edgtf-banner-button">
                        <?php echo pxlz_edgtf_get_button_html(array(
                            'link' => $button_link,
                            'text' => $button_label,
                            'type' => 'solid',
                            'size' => 'small',
                            'plus_sign' => true,
                            'color' => $button_color,
                            'background_color' => $button_background_color
                        )); ?>
                    </div>
                <?php endif; ?>

            </div><!-- .content -->

        <?php endif; ?>

    </div>
</div>