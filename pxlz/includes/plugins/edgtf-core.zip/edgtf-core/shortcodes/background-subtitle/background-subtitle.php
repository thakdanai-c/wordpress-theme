<?php
namespace EdgeCore\CPT\Shortcodes\BackgroundSubtitle;

use EdgeCore\Lib;

class BackgroundSubtitle implements Lib\ShortcodeInterface
{
    private $base;

    public function __construct() {
        $this->base = 'edgtf_background_subtitle';

        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if (function_exists('vc_map')) {
            vc_map(
                array(
                    'name' => esc_html__('Edge Background Subtitle', 'edgtf-core'),
                    'base' => $this->getBase(),
                    'category' => esc_html__('by EDGE', 'edgtf-core'),
                    'icon' => 'icon-wpb-background-subtitle extended-custom-icon',
                    'allowed_container_element' => 'vc_row',
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'param_name' => 'subtitle',
                            'heading' => esc_html__('Subtitle Text', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'colorpicker',
                            'param_name' => 'color',
                            'heading' => esc_html__('Color', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'font_size',
                            'heading' => esc_html__('Font Size (px)', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'alignment',
                            'heading' => esc_html__('Alignment', 'edgtf-core'),
                            'value' => array(
                                esc_html__('Left', 'edgtf-core') => 'edgtf-align-left',
                                esc_html__('Center', 'edgtf-core') => 'edgtf-align-center',
                                esc_html__('Right', 'edgtf-core') => 'edgtf-align-right',
                            ),
                            'save_always' => true
                        ),
                        array(
                            'type' => 'checkbox',
                            'param_name' => 'rotate',
                            'heading' => esc_html__('Rotate', 'edgtf-core'),
                            'description' => esc_html__('Rotate heading for 90 degrees ccw', 'edgtf-core'),
                            'save_always' => true,
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'horizontal_offset',
                            'heading' => esc_html__('Horizontal Offset (px or %)', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'vertical_offset',
                            'heading' => esc_html__('Vertical Offset (px or %)', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'font_size_responsive',
                            'heading' => esc_html__('Font Size (px)', 'edgtf-core'),
                            'group' => esc_html__('Options (between 1280px and 1024px)', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'horizontal_offset_responsive',
                            'heading' => esc_html__('Horizontal Offset (px or %)', 'edgtf-core'),
                            'group' => esc_html__('Options (between 1280px and 1024px)', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'vertical_offset_responsive',
                            'heading' => esc_html__('Vertical Offset (px or %)', 'edgtf-core'),
                            'group' => esc_html__('Options (between 1280px and 1024px)', 'edgtf-core'),
                        ),
                        array(
                            'type' => 'dropdown',
                            'param_name' => 'animate_on_appear',
                            'heading' => esc_html__('Animate On Appear', 'edgtf-core'),
                            'value' => array_flip(pxlz_edgtf_get_yes_no_select_array(false, true)),
                        ),
                    )
                )
            );
        }
    }

    public function render($atts, $content = null) {
        $args = array(
            'subtitle' => '',
            'color' => '',
            'font_size' => '80',
            'alignment' => 'edgtf-align-left',
            'rotate' => '',
            'horizontal_offset' => '',
            'vertical_offset' => '',
            'font_size_responsive' => '',
            'horizontal_offset_responsive' => '',
            'vertical_offset_responsive' => '',
            'animate_on_appear' => 'yes'
        );

        $params = shortcode_atts($args, $atts);

        $params['holder_classes'] = $this->getHolderClasses($params);
        $params['holder_styles'] = $this->getHolderStyles($params);
        $params['data_atts'] = $this->getDataAtts($params);

        $html = edgtf_core_get_shortcode_module_template_part('templates/background-subtitle', 'background-subtitle', '', $params);

        return $html;
    }

    private function getDataAtts($params) {
        $data = array();

        if ($params['font_size_responsive'] !== '') {
            $data['data-font-size'] = pxlz_edgtf_filter_px($params['font_size_responsive']) . 'px';
        }

        if ($params['horizontal_offset_responsive'] !== '') {
            $data['data-horizontal-offset'] = $params['horizontal_offset_responsive'];
        }

        if ($params['vertical_offset_responsive'] !== '') {
            $data['data-vertical-offset'] = $params['vertical_offset_responsive'];
        }

        return $data;
    }

    private function getHolderClasses($params) {
        $holderClasses = array();

        $holderClasses[] = 'edgtf-background-subtitle';
        $holderClasses[] = $params['alignment'];

        if (!empty($params['rotate'])) {
            $holderClasses[] = 'edgtf-rotate';
        }

        if ($params['animate_on_appear'] == 'yes') {
            $holderClasses[] = 'edgtf-animate';
        }

        return implode(' ', $holderClasses);
    }

    private function getHolderStyles($params) {
        $holderStyles = array();

        if (!empty($params['color'])) {
            $holderStyles[] = 'color:' . $params['color'];
        }
        if (!empty($params['horizontal_offset'])) {
            $holderStyles[] = 'left: ' . $params['horizontal_offset'];
        }
        if (!empty($params['vertical_offset'])) {
            $holderStyles[] = 'top: ' . $params['vertical_offset'];
        }
        if (!empty($params['font_size'])) {
            $holderStyles[] = 'font-size: ' . pxlz_edgtf_filter_px($params['font_size']) . 'px';
        }

        return implode(';', $holderStyles);
    }
}