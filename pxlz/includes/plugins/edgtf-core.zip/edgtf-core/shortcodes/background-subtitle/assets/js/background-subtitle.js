(function ($) {
    'use strict';

    var backgroundSubtitle = {};
    edgtf.modules.backgroundSubtitle = backgroundSubtitle;

    backgroundSubtitle.edgtfInitBackgroundSubtitle = edgtfInitBackgroundSubtitle;
    backgroundSubtitle.edgtfBackgroundSubtitleAnimation = edgtfBackgroundSubtitleAnimation;


    backgroundSubtitle.edgtfOnDocumentReady = edgtfOnDocumentReady;

    $(document).ready(edgtfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function edgtfOnDocumentReady() {
        edgtfInitBackgroundSubtitle();
        edgtfBackgroundSubtitleAnimation();
    }

    function edgtfInitBackgroundSubtitle() {
        var holder = $('.edgtf-background-subtitle');

        if (holder.length) {
            holder.each(function () {
                var fontSize = '',
                    horizontalOffset = '',
                    verticalOffset = '',
                    selector = '',
                    customStyle = '',
                    style = '';

                if (typeof $(this).data('font-size') !== 'undefined') {
                    fontSize = $(this).data('font-size');
                }

                if (typeof $(this).data('horizontal-offset') !== 'undefined') {
                    horizontalOffset = $(this).data('horizontal-offset');
                }

                if (typeof $(this).data('vertical-offset') !== 'undefined') {
                    verticalOffset = $(this).data('vertical-offset');
                }

                if (fontSize.length || horizontalOffset.length || verticalOffset.length) {
                    selector = '#' + $(this).attr('id');

                    console.log(selector);

                    if (fontSize.length) {
                        customStyle += 'font-size:' + fontSize + '!important;';
                    }

                    if (horizontalOffset.length) {
                        customStyle += 'left:' + horizontalOffset + '!important;';
                    }

                    if (verticalOffset.length) {
                        customStyle += 'top:' + verticalOffset + '!important;';
                    }
                }

                if (customStyle.length) {
                    style = '<style type="text/css">@media(max-width:1280px){' + selector + '{' + customStyle + '}}</style>';
                }

                if (style.length) {
                    $('head').append(style);
                }
            });
        }
    }

    function edgtfBackgroundSubtitleAnimation() {
        var subtitles = $('.edgtf-background-subtitle.edgtf-animate');

        if (subtitles.length && !edgtf.htmlEl.hasClass('touch')) {
            subtitles.each(function () {
                var subtitle = $(this),
                    holder = subtitle.parent();

                holder.appear(function () {
                    subtitle.addClass('edgtf-appeared');
                }, {accX: 0, accY: edgtfGlobalVars.vars.edgtfElementAppearAmount});
            });
        }
    };

})(jQuery);