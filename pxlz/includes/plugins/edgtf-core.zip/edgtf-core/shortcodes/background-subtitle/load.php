<?php

include_once EDGE_CORE_SHORTCODES_PATH . '/background-subtitle/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH . '/background-subtitle/background-subtitle.php';