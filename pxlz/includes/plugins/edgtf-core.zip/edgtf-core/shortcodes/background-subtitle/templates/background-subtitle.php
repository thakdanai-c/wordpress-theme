<div
    class="<?php echo esc_attr($holder_classes); ?>"
    style="<?php echo esc_attr($holder_styles); ?>"
    id="edgtf-background-subtitle-<?php echo rand(0, 1000); ?>"
    <?php echo pxlz_edgtf_get_inline_attrs($data_atts); ?>>
    <div class="edgtf-background-subtitle-inner">
        <?php echo esc_attr($subtitle); ?>
    </div>
</div>