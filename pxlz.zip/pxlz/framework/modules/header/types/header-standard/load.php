<?php

include_once EDGE_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard/functions.php';
include_once EDGE_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard/header-standard.php';