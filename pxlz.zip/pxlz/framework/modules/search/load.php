<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/search/functions.php';

//load global search options
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/search/admin/options-map/search-map.php';