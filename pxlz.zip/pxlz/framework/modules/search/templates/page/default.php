<?php pxlz_edgtf_get_module_template_part( 'templates/parts/search-form', 'search', '', $params ); ?>
<?php pxlz_edgtf_get_module_template_part( 'templates/parts/loop', 'search', '', $params ); ?>
<?php pxlz_edgtf_get_module_template_part( 'templates/parts/pagination', 'search', '', $params ); ?>