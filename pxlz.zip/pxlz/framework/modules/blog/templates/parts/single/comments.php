<?php
if (pxlz_edgtf_show_comments()) {
    comments_template('', true);
}