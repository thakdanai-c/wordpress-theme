<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/plugins/yith-quick-view/yith-quick-view-conf.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR . '/woocommerce/plugins/yith-quick-view/yith-quick-view-functions.php';