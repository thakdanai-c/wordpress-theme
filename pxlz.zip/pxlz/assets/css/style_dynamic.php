<?php

do_action('pxlz_edgtf_style_dynamic');