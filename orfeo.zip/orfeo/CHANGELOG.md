
 ### v1.0.6 - 2018-09-02 
 **Changes:** 
 * Fixed WC Coupon notice and button on Checkout Page
* Fixed alignment issues in the Big Title section
* Fixed issue with the background color on the Blog page
* Updated screenshot to match with the new wp.org requirements
 
 ### v1.0.5 - 2018-02-01 
 **Changes:** 
 * Fixed RTL compatibility issues
* Fixed compatibility with Portfolio and Pricing sections from Hestia PRO
* Removed unnecessary strings
 
 ### v1.0.4 - 2018-01-26 
 **Changes:** 
 * Improved the copyright mentioning the parent theme
* Fixed some escaping issues
 
 ### v1.0.3 - 2018-01-22 
 **Changes:** 
 * Added grunt task for pot file
 
 ### v1.0.2 - 2018-01-19 
 **Changes:** 
 * Option for second button in the big title section
 
 ### v1.0.1 - 2018-01-19 
 **Changes:** 
 * Updated screenshot
* Filtered the About page messages and welcome notice
 
 ### v1.0.0 - 2018-01-18 
 **Changes:** 
 First version
  
